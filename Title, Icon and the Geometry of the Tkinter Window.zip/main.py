from tkinter import *

root = Tk()
root.geometry('300x300')
root.title("MusicBeats")
root.iconbitmap(r'musicbeats.ico')

root.mainloop()