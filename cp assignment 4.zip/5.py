def energy(m,v):
    ke=0.5*(m*(v**2))
    return ke
m=int(input("Enter mass:"))
v=int(input("Enter velocity:"))

c=energy(m,v)
print(c)