row=10
for i in range(1,row,2):
        for j in range(row-1,i,-2):
             print(" ",end=" ")
        mid_value=0
        for n in range(0,i):
          mid_value+=n
        mid_value=mid_value/i
        for k in range(0,i):
            if(i+1==row):
              print("3",end=" ")
            elif(mid_value==k):
              print("3",end=" ")
            else:
              print("6",end=" ")
        print()
for j in range(row-1,0,-2):
     if (j!=row-1):
             for k in range(j,row-1,2):
               print(" ",end=" ")
             mid_value=0
             for n in range(0,j):
               mid_value+=n
             mid_value=mid_value/j
             for i in range(0,j):
                if(j+1==row-1):
                    print("3", end=" ")
                elif(mid_value==i):
                    print("3",end=" ")
                else:
                    print("6", end=" ")
             print()