n=int(input("Enter the number :"))
def fab():
 a=0
 print(a,end=",")
 b=1
 print(b,end=",")
 c=a+b
 for i in range(3,n):
   print(c,end=",")
   a=b
   b=c
   c=a+b
 return c
print(fab())