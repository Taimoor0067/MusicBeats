def prime(x):
    for i in range(2,x):
     if x%i ==0:
        print("Not prime")
        break
     else:  
        print("prime")
        break
      
      
x=int(input("Enter a number:"))
prime (x)