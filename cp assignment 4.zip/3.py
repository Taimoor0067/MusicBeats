
def num():
  num=int(input("Enter a number:"))
  b=num
  a=1
  newnum=0
  while(num>0):
       rem=num%10
       num=num//10
       newnum=newnum*10+(rem)
  print("reverse number is",newnum)    

  if(b==newnum):
     print("Same")
  else:
     print("Not same")
num()
