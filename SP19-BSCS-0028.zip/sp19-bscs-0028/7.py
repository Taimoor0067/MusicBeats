import math
num=int(input("enter a non negative integer:"))
i=0
while(i<=0):
   if(num>0):
       print("factorial of given number is:",math.factorial (num))
   i+=1
