a=0
while(a!=1):
    i=input("Enter No:")
    if(i=="x"):
       break
    b=int(i)
    if((b**0.5)**2==b):
        print(b,"is a perfect square of",format(b**0.5,'.0f'))
    else:
        print(b,"is not a perfect square")
print("The End")

 
