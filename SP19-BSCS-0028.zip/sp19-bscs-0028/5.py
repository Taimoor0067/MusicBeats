Miles=1.60934
for i in range(10,90,10):
  a=Miles*i
  print("Miles in",i,":",format(a,'.2f'))
