number="x"
count1=0
count2=0
i=1
while(i<=28):
   num=int(input("Enter a number:"))
   if(num>0):
     count1+=1
   elif(num<0):
     count2+=1
   if number==input("Enter x to stop:"):
               break
   i+=1
print("Total positive number entered=",count1)
print("Total negative number entered=",count2)
