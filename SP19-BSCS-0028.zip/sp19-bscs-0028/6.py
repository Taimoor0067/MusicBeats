x=1.6
for i in range(1,26):
   y=x*i
   print("Ocean level in",i,"year",":",y)