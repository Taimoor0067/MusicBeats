a=input("enter a word:")
L=len(a)
i=1
n=0
while i>0: 
      if a=="":
          print("THE END")
          break
      a=input("enter a word:")
      L+=len(a)
      n+=1
print("Average length is:",L/n)
