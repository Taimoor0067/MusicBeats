a=1
while(a<6):
  b=1
  while(b<6-a):
    print(" " ,end=' ')
    b+=1
  c=1
  while(c < a*2):
    if(c%2!=0):
       print("2",end=' ')
    else:
       print("8",end=' ')
    c+=1
  a+=1
  print("")