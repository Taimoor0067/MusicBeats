from tkinter import *

root = Tk()
root.geometry('300x300')
root.title("MusicBeats")
root.iconbitmap(r'musicbeats.ico')

text = Label(root, text='Lets Play some Musics!')
text.pack()

photo = PhotoImage(file='play.png')
labelphoto = Label(root, image = photo)
labelphoto.pack()

root.mainloop()
